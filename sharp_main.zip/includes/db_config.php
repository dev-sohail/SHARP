<?php

//Add the application is installed
//Data base setting  ssss
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
// define('DB_HOSTNAME', '%');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'NXWAPPS_sharp');
define('DB_PREFIX', '');

#
#Email configurations
#


define('config_mail_protocol','mail'); 
define('config_smtp_host','');
define('config_smtp_username','');
define('config_smtp_password','Y');
define('config_smtp_port','');
define('config_smtp_timeout',''); 

