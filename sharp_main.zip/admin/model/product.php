<?php
class ModelProduct extends Model
{
    public function addProduct($data)
	{
        $defaultImageFileName = "no_image-100x100.png";
        $icon = $defaultImageFileName;
 
        if (!empty($_FILES["icon"]["name"])) {
            $targetDirectory = DIR_IMAGE . "product/";
            $targetFile = $targetDirectory . basename($_FILES["icon"]["name"]);
            if (!is_dir($targetDirectory)) {
                mkdir($targetDirectory, 0755);
            }
            move_uploaded_file($_FILES["icon"]["tmp_name"], $targetFile);
            $icon = $this->db->escape($_FILES["icon"]["name"]);
        }
        $status = $this->db->escape($data['status']);
		$sortOrder = $this->db->escape($data['sort_order']);
        $made_in = $this->db->escape($data['made_in']);
        $numberOfStars = (int)$data['number_of_stars'];
        $insertProductQuery = "INSERT INTO `" . DB_PREFIX . "product` SET 
        icon = '" . $icon . "',
        number_of_stars = '" . (int)$numberOfStars . "', 
        made_in = '" . $made_in . "',
        sort_order = '" . (int)$sortOrder . "',
        status = '" . $status . "',
        date_added = NOW()";
        $this->db->query($insertProductQuery);
        $productId = $this->db->getLastId();
        foreach ($data['product_description'] as $languageId => $languageValue) {
            $languageId = (int)$languageId;
            $title = $this->db->escape($languageValue['title']);
            $description = $this->db->escape($languageValue['description']);
            $short_description = $this->db->escape($languageValue['short_description']);
            $insertDescriptionQuery = "INSERT INTO " . DB_PREFIX . "product_description SET 
            product_id = '" . (int)$productId . "',
            lang_id = '" . $languageId . "',
            title = '" . $title . "',
            description = '" . $description . "',
            short_description = '" . $short_description . "'";
            $this->db->query($insertDescriptionQuery);
        }
    }

    public function getProduct($productId)
	{
		$query = $this->db->query($sql = "SELECT * FROM `" . DB_PREFIX . "product` WHERE id = " . (int)$productId);
		return $query->row;
	}

    public function getProductDescriptions($productId)
    {
        $product_description_data = array();
		$sql = "SELECT * FROM `" . DB_PREFIX . "product_description` WHERE product_id = " . (int)$productId;
		$query = $this->db->query($sql);
		foreach ($query->rows as $result) {
			$product_description_data[$result['lang_id']] = array(
				'title'             => $result['title'],
				'description'       => $result['description'],
				'short_description'       => $result['short_description']
			);
		}
		return $product_description_data;
    }

	public function getProducts($languageId, $data = array())
	{
		$languageId = (int)$languageId;
		$sql = "SELECT pd.*, p.* 
				FROM `" . DB_PREFIX . "product` p
				LEFT JOIN `" . DB_PREFIX . "product_description` pd ON p.id = pd.product_id
				WHERE pd.lang_id = '" . $languageId . "' or  pd.lang_id = 1
				ORDER BY p.id";
		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " DESC";
		}
		$query = $this->db->query($sql);
		return $query->rows;
	}

	public function getTotalproducts()
	{
		$query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "product`");
		return $query->row['total'];
	}

    public function getMadeInOptions()
    {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` ORDER BY name");
        $made_in_options = [];
        foreach ($query->rows as $row) {
            $made_in_options[] = [
                'country_id' => $row['country_id'],
                'name' => $row['name']
            ];
        }
        return $made_in_options;
    }

    public function updateProductStatus($productId, $status) 
    {
		$this->db->query("UPDATE `" . DB_PREFIX . "product` SET status = '" . (int)$status . "' WHERE id = '" . (int)$productId . "'");
	}

    public function editProduct($productId, $data)
    {
        $targetDirectory = DIR_IMAGE . "product/";
        $icon = '';
        if (!empty($_FILES["icon"]["name"])) {
            $icon = $_FILES["icon"]["name"];
            $targetFile = $targetDirectory . basename($icon);
            move_uploaded_file($_FILES["icon"]["tmp_name"], $targetFile);
            $icon = $this->db->escape($icon);
        }
        if (!empty($icon)) {
            $updateImageQuery = "UPDATE `" . DB_PREFIX . "product` SET
            icon = '" . $icon . "'
            WHERE id = '" . (int)$productId . "'";
            $this->db->query($updateImageQuery);
        }
        $status = $this->db->escape($data['status']);
		$sortOrder = $this->db->escape($data['sort_order']);
        $made_in = $this->db->escape($data['made_in']);
        $updateProductQuery = "UPDATE `" . DB_PREFIX . "product` SET
        status = '" . $status . "',
        made_in = '" . $made_in . "',
        sort_order = '" . $sortOrder . "',
        date_modified = NOW()
        WHERE id = '" . (int)$productId . "'";
        $this->db->query($updateProductQuery);
        $deleteDescriptionQuery = "DELETE FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$productId . "'";
        $this->db->query($deleteDescriptionQuery);
        foreach ($data['product_description'] as $languageId => $languageValue) {
            $languageId = (int)$languageId;
            $title = $this->db->escape($languageValue['title']);
            $description = $this->db->escape($languageValue['description']);
            $short_description = $this->db->escape($languageValue['short_description']);
            $updateDescriptionQuery = "INSERT INTO " . DB_PREFIX . "product_description SET 
            product_id = '" . (int)$productId . "',
            lang_id = '" . $languageId . "',
            title = '" . $title . "',
            description = '" . $description . "',
            short_description = '" . $short_description . "'";
            $this->db->query($updateDescriptionQuery);
        }
    // die($updateProductQuery);
    }

    public function deleteProduct($productId)
    {
        $this->db->query("DELETE FROM " . DB_PREFIX . "product WHERE id = '" . (int)$productId . "'");
        $this->db->query("DELETE FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$productId . "'");
    }
}